use vstd::prelude::*;

use core::marker::PhantomData;

use crate::arch::mm::PagingConsts;
use crate::mm::page_prop::PageProperty;
use crate::mm::page_table::*;
use crate::mm::{Paddr, PagingConstsTrait, PagingLevel, Vaddr, page_size};
use crate::specs::arch::*;
use crate::specs::arch::{NR_ENTRIES, NR_LEVELS, PAGE_SIZE};
use vstd_extra::ownership::*;

verus! {

pub open spec fn level_is_in_range(level: int) -> bool {
    1 <= level <= NR_LEVELS as int
}

pub open spec fn index_is_in_range(index: int) -> bool {
    0 <= index < NR_ENTRIES
}

pub open spec fn pa_is_valid_pt_address(pa: int) -> bool {
    &&& pa_is_valid_kernel_address(pa as int)
    &&& pa % PAGE_SIZE as int == 0
}

pub open spec fn PHYSICAL_BASE_ADDRESS_SPEC() -> usize {
    0
}

pub open spec fn pa_is_valid_kernel_address(pa: int) -> bool {
    PHYSICAL_BASE_ADDRESS_SPEC() <= pa < PHYSICAL_BASE_ADDRESS_SPEC() + PAGE_SIZE * MAX_NR_PAGES
}

pub ghost struct LeafPageTableEntryView<C: PageTableConfig> {
    pub map_va: int,
    //    pub frame_pa: int,
    //    pub in_frame_index: int,
    pub map_to_pa: int,
    pub level: PagingLevel,
    pub prop: PageProperty,
    pub phantom: PhantomData<C>,
}

impl<C: PageTableConfig> Inv for LeafPageTableEntryView<C> {
    open spec fn inv(self) -> bool {
        //        &&& pa_is_valid_pt_address(self.frame_pa)
        //        &&& index_is_in_range(self.in_frame_index)
        &&& pa_is_valid_kernel_address(
            self.map_to_pa,
        )
        // We assume that all level PTEs can be leaf. Thus they can map to huge pages.
        &&& level_is_in_range(
            self.level as int,
        )
        // The corresponding virtual address must be aligned to the page size.
        &&& self.map_va % (page_size(self.level) as int) == 0
    }
}

impl<C: PageTableConfig> LeafPageTableEntryView<C> {
    pub open spec fn va_end(self) -> Vaddr {
        (self.map_va + page_size(self.level)) as Vaddr
    }
}

pub ghost struct IntermediatePageTableEntryView<C: PageTableConfig> {
    pub map_va: int,
    //    pub frame_pa: int,
    //    pub in_frame_index: int,
    pub map_to_pa: int,
    pub level: PagingLevel,
    pub phantom: PhantomData<C>,
}

impl<C: PageTableConfig> Inv for IntermediatePageTableEntryView<C> {
    open spec fn inv(self) -> bool {
        //        &&& pa_is_valid_pt_address(self.frame_pa)
        //        &&& index_is_in_range(self.in_frame_index)
        &&& pa_is_valid_pt_address(self.map_to_pa)
        &&& level_is_in_range(self.level as int)
        // No self-loop.
        //        &&& self.map_to_pa != self.frame_pa
        // The corresponding virtual address must be aligned to the page size.
        &&& self.map_va % (page_size(self.level) as int) == 0
    }
}

pub ghost struct FrameView<C: PageTableConfig> {
    /// A map from the ancestor frame level to the PTE that the ancestor maps to its child.
    pub ancestor_chain: Map<int, IntermediatePageTableEntryView<C>>,
    /// The view of the page table leaf entry
    pub leaf: LeafPageTableEntryView<C>,
}

impl<C: PageTableConfig> Inv for FrameView<C> {
    open spec fn inv(self) -> bool {
        true
    }
}

impl<C: PageTableConfig> LeafPageTableEntryView<C> {
    pub open spec fn to_frame_view(
        self,  /*, ancestors: Map<int, IntermediatePageTableEntryView<C>>*/
    ) -> FrameView<C> {
        FrameView { ancestor_chain: Map::empty(), leaf: self }
    }
}

pub ghost enum EntryView<C: PageTableConfig> {
    Leaf { leaf: LeafPageTableEntryView<C> },
    Intermediate { node: IntermediatePageTableEntryView<C> },
    Absent,
}

impl<C: PageTableConfig> Inv for EntryView<C> {
    open spec fn inv(self) -> bool {
        true/*
        match self {
            Self::Leaf { leaf: _ } => self->leaf.inv(),
            Self::Intermediate { node: _ } => self->node.inv(),
            Self::Absent => true,
        }
        */

    }
}

} // verus!
